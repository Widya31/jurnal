<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mapel extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_mapel',
    ];

    public function guru()
    {
        return $this->hasMany(Guru::class, 'id_mapel');
    }
    
    public function jurnal()
    {
        return $this->hasMany(Jurnal::class, 'id_mapel');
    }
}
