<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use App\Models\Mapel;
use Illuminate\Http\Request;

class GuruController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get gurus
        $gurus = Guru::latest()->paginate(5);
        $mapels = Mapel::all();

        //render view with gurus
        return view('gurus.index', compact('gurus', 'mapels'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $mapels = Mapel::all();

        return view('gurus.create', compact('mapels'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate form
        $this->validate($request, [
            'nama_guru'     => 'required|min:5',
            'id_mapel'     => 'required',
        ]);

        Guru::create([
            'nama_guru'     => $request->nama_guru,
            'id_mapel'     => $request->id_mapel,
        ]);

        //redirect to index
        return redirect()->route('gurus.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Guru $guru)
    {
        $mapels = Mapel::all();

        return view('gurus.edit', compact('mapels', 'guru'));
    }
    
    /**
     * update
     *
     * @param  mixed $request
     * @param  mixed $mapel
     * @return void
     */
    public function update(Request $request, Guru $guru)
    {
        //validate form
        $this->validate($request, [
            'nama_guru'     => 'required|min:5',
            'id_mapel'     => 'required',
        ]);

        $guru->update([
            'nama_guru'     => $request->nama_guru,
            'id_mapel'     => $request->id_mapel,
         ]);

        //redirect to index
        return redirect()->route('gurus.index')->with(['success' => 'Data Berhasil Diubah!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Guru $guru)
    {
        $guru->delete();

        return redirect()->route('gurus.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
