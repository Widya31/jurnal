<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Data Jurnal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                    <form action="{{ route('jurnals.update', $jurnal->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="form-group">
                                <label class="font-weight-bold">GURU</label>
                                <select class="form-control @error('id_guru') is-invalid @enderror" name="id_guru" size="1">
                                    @foreach($gurus as $guru)
                                        <option value="{{ $guru->id }}" {{ ($jurnal->id_guru == $guru->id) ? 'selected' : '' }}>{{ $guru->nama_guru }}</option>
                                    @endforeach
                                </select>

                                <!-- error message untuk id_guru -->
                                @error('id_guru')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">MAPEL</label>
                                <select class="form-control @error('id_mapel') is-invalid @enderror" name="id_mapel" size="1">
                                    @foreach($mapels as $mapel)
                                        <option value="{{ $mapel->id }}" {{ ($jurnal->id_mapel == $mapel->id) ? 'selected' : '' }}>{{ $mapel->nama_mapel }}</option>
                                    @endforeach
                                </select>

                                <!-- error message untuk id_guru -->
                                @error('id_mapel')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">KEHADIRAN</label>
                                <select class="form-control @error('kehadiran') is-invalid @enderror" name="kehadiran" size="1">
                                    <option value="" selected disabled>~ Pilih kehadiran & Jurusan ~</option>
                                    <option value="Hadir" {{ (old('kehadiran', $jurnal->kehadiran) == 'Hadir') ? 'selected' : '' }}>Hadir</option>
                                    <option value="Tidak Hadir" {{ (old('kehadiran', $jurnal->kehadiran) == 'Tidak Hadir') ? 'selected' : '' }}>Tidak Hadir</option>
                                    <option value="Tidak Hadir - Tugas" {{ (old('kehadiran', $jurnal->kehadiran) == 'Tidak Hadir - Tugas') ? 'selected' : '' }}>Tidak Hadir - Tugas</option>
                                </select>

                                <!-- error message untuk nama -->
                                @error('kehadiran')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            
                            <div class="form-group">
                                <label class="font-weight-bold">MATERI/KETERANGAN</label>
                                <input type="text" class="form-control @error('materi') is-invalid @enderror" name="materi" value="{{ old('materi', $jurnal->materi) }}">
                            
                                @error('materi')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">JAM PELAJARAN KE-</label>
                                <select class="form-control @error('jamke') is-invalid @enderror" name="jamke" size="1">
                                    <option value="" selected disabled>~ Pilih Jam Ke- ~</option>
                                    <option value="1" {{ (old('jamke', $jurnal->jamke) == '1') ? 'selected' : '' }}>1</option>
                                    <option value="2" {{ (old('jamke', $jurnal->jamke) == '2') ? 'selected' : '' }}>2</option>
                                    <option value="3" {{ (old('jamke', $jurnal->jamke) == '3') ? 'selected' : '' }}>3</option>
                                    <option value="4" {{ (old('jamke', $jurnal->jamke) == '4') ? 'selected' : '' }}>4</option>
                                    <option value="5" {{ (old('jamke', $jurnal->jamke) == '5') ? 'selected' : '' }}>5</option>
                                    <option value="6" {{ (old('jamke', $jurnal->jamke) == '6') ? 'selected' : '' }}>6</option>
                                    <option value="7" {{ (old('jamke', $jurnal->jamke) == '7') ? 'selected' : '' }}>7</option>
                                    <option value="8" {{ (old('jamke', $jurnal->jamke) == '8') ? 'selected' : '' }}>8</option>
                                    <option value="9" {{ (old('jamke', $jurnal->jamke) == '9') ? 'selected' : '' }}>9</option>
                                    <option value="10" {{ (old('jamke', $jurnal->jamke) == '10') ? 'selected' : '' }}>10</option>
                                </select>

                                <!-- error message untuk nama -->
                                @error('jamke')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">TANGGAL</label>
                                <input type="date" class="form-control @error('tgl') is-invalid @enderror" name="tgl" value="{{ old('tgl', $jurnal->tgl) }}">
                            
                                <!-- error message untuk tgl_bayar -->
                                @error('tgl')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <button type="submit" class="btn btn-md btn-primary">UPDATE</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
</body>
</html>