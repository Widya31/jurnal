<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Data Jurnal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                    <form action="<?php echo e(route('jurnals.update', $jurnal->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label class="font-weight-bold">GURU</label>
                                <select class="form-control <?php $__errorArgs = ['id_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_guru" size="1">
                                    <?php $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($guru->id); ?>" <?php echo e(($jurnal->id_guru == $guru->id) ? 'selected' : ''); ?>><?php echo e($guru->nama_guru); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <!-- error message untuk id_guru -->
                                <?php $__errorArgs = ['id_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">MAPEL</label>
                                <select class="form-control <?php $__errorArgs = ['id_mapel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_mapel" size="1">
                                    <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($mapel->id); ?>" <?php echo e(($jurnal->id_mapel == $mapel->id) ? 'selected' : ''); ?>><?php echo e($mapel->nama_mapel); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <!-- error message untuk id_guru -->
                                <?php $__errorArgs = ['id_mapel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">KEHADIRAN</label>
                                <select class="form-control <?php $__errorArgs = ['kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kehadiran" size="1">
                                    <option value="" selected disabled>~ Pilih kehadiran & Jurusan ~</option>
                                    <option value="Hadir" <?php echo e((old('kehadiran', $jurnal->kehadiran) == 'Hadir') ? 'selected' : ''); ?>>Hadir</option>
                                    <option value="Tidak Hadir" <?php echo e((old('kehadiran', $jurnal->kehadiran) == 'Tidak Hadir') ? 'selected' : ''); ?>>Tidak Hadir</option>
                                    <option value="Tidak Hadir - Tugas" <?php echo e((old('kehadiran', $jurnal->kehadiran) == 'Tidak Hadir - Tugas') ? 'selected' : ''); ?>>Tidak Hadir - Tugas</option>
                                </select>

                                <!-- error message untuk nama -->
                                <?php $__errorArgs = ['kehadiran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="form-group">
                                <label class="font-weight-bold">MATERI/KETERANGAN</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="materi" value="<?php echo e(old('materi', $jurnal->materi)); ?>">
                            
                                <?php $__errorArgs = ['materi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">JAM PELAJARAN KE-</label>
                                <select class="form-control <?php $__errorArgs = ['jamke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jamke" size="1">
                                    <option value="" selected disabled>~ Pilih Jam Ke- ~</option>
                                    <option value="1" <?php echo e((old('jamke', $jurnal->jamke) == '1') ? 'selected' : ''); ?>>1</option>
                                    <option value="2" <?php echo e((old('jamke', $jurnal->jamke) == '2') ? 'selected' : ''); ?>>2</option>
                                    <option value="3" <?php echo e((old('jamke', $jurnal->jamke) == '3') ? 'selected' : ''); ?>>3</option>
                                    <option value="4" <?php echo e((old('jamke', $jurnal->jamke) == '4') ? 'selected' : ''); ?>>4</option>
                                    <option value="5" <?php echo e((old('jamke', $jurnal->jamke) == '5') ? 'selected' : ''); ?>>5</option>
                                    <option value="6" <?php echo e((old('jamke', $jurnal->jamke) == '6') ? 'selected' : ''); ?>>6</option>
                                    <option value="7" <?php echo e((old('jamke', $jurnal->jamke) == '7') ? 'selected' : ''); ?>>7</option>
                                    <option value="8" <?php echo e((old('jamke', $jurnal->jamke) == '8') ? 'selected' : ''); ?>>8</option>
                                    <option value="9" <?php echo e((old('jamke', $jurnal->jamke) == '9') ? 'selected' : ''); ?>>9</option>
                                    <option value="10" <?php echo e((old('jamke', $jurnal->jamke) == '10') ? 'selected' : ''); ?>>10</option>
                                </select>

                                <!-- error message untuk nama -->
                                <?php $__errorArgs = ['jamke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">TANGGAL</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tgl" value="<?php echo e(old('tgl', $jurnal->tgl)); ?>">
                            
                                <!-- error message untuk tgl_bayar -->
                                <?php $__errorArgs = ['tgl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-md btn-primary">UPDATE</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\jurnal\resources\views/jurnals/edit.blade.php ENDPATH**/ ?>